from flask import Flask, request, jsonify
from flask_cors import CORS
import hashlib
import json
import requests
from datetime import datetime
import os
import logging

app = Flask(__name__)
CORS(app)

# Configuration
OPA_URL = os.getenv('OPA_URL', 'http://opa:8181')

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Stockage en mémoire
MOCK_DEVICES = {}

# Pondération des checks de compliance
COMPLIANCE_CHECKS = {
    'os_updated': 20,
    'antivirus_active': 20,
    'firewall_enabled': 15,
    'disk_encrypted': 25,
    'screen_lock': 10,
    'no_malware': 10
}

# ============================================
# FONCTIONS UTILITAIRES
# ============================================
def calculate_compliance_score(checks):
    """Calcule le score de compliance basé sur les checks"""
    total = sum(COMPLIANCE_CHECKS[k] for k, v in checks.items() if v)
    max_score = sum(COMPLIANCE_CHECKS.values())
    return int((total / max_score) * 100)

def assess_device(data):
    """Évalue le niveau de confiance du device"""
    checks = {
        'os_updated': data.get('os_version_current', False),
        'antivirus_active': data.get('antivirus_active', False),
        'firewall_enabled': data.get('firewall_enabled', False),
        'disk_encrypted': data.get('disk_encrypted', False),
        'screen_lock': data.get('screen_lock_enabled', False),
        'no_malware': not data.get('malware_detected', False)
    }
    
    score = calculate_compliance_score(checks)
    
    if score >= 90:
        return {'score': score, 'level': 'high', 'trusted': True}
    elif score >= 70:
        return {'score': score, 'level': 'medium', 'trusted': True}
    elif score >= 50:
        return {'score': score, 'level': 'low', 'trusted': False}
    else:
        return {'score': score, 'level': 'critical', 'trusted': False}

def generate_device_id(data):
    """Génère un ID unique pour le device basé sur ses caractéristiques"""
    fingerprint = json.dumps({
        'os': data.get('os', ''),
        'os_version': data.get('os_version', ''),
        'user_agent': data.get('user_agent', ''),
        'hostname': data.get('hostname', '')
    }, sort_keys=True)
    return hashlib.sha256(fingerprint.encode()).hexdigest()[:16]

def update_opa(device_info):
    """Met à jour OPA avec les infos du device"""
    try:
        data = {
            "devices": {
                device_info['device_id']: {
                    "trusted": device_info['trusted'],
                    "compliance_score": device_info['compliance_score'],
                    "trust_level": device_info['trust_level']
                }
            }
        }
        
        response = requests.put(
            f"{OPA_URL}/v1/data/devices",
            json=data,
            timeout=2
        )
        return response.status_code == 204
    except Exception as e:
        logger.error(f"Erreur mise à jour OPA: {e}")
        return False

# ============================================
# ENDPOINTS
# ============================================
@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'healthy',
        'service': 'device-posture',
        'devices_count': len(MOCK_DEVICES),
        'opa_connected': check_opa_connection()
    })

def check_opa_connection():
    try:
        response = requests.get(f"{OPA_URL}/health", timeout=2)
        return response.status_code == 200
    except:
        return False

@app.route('/api/register', methods=['POST'])
def register():
    """Enregistre un nouveau device"""
    data = request.get_json()
    
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    device_id = generate_device_id(data)
    assessment = assess_device(data)
    
    device_info = {
        'device_id': device_id,
        'user_id': data.get('user_id'),
        'device_name': data.get('device_name', 'Unknown'),
        'os': data.get('os', 'Unknown'),
        'compliance_score': assessment['score'],
        'trust_level': assessment['level'],
        'trusted': assessment['trusted'],
        'registered_at': datetime.utcnow().isoformat(),
        'last_seen': datetime.utcnow().isoformat()
    }
    
    MOCK_DEVICES[device_id] = device_info
    update_opa(device_info)
    
    logger.info(f"✅ Device enregistré: {device_id} (trusted: {assessment['trusted']}, score: {assessment['score']})")
    
    return jsonify({
        'device_id': device_id,
        'assessment': assessment,
        'message': 'Device registered successfully'
    }), 201

@app.route('/api/check', methods=['POST'])
def check():
    """Vérifie le statut d'un device"""
    data = request.get_json()
    device_id = data.get('device_id')
    
    if not device_id:
        # Si pas d'ID, on essaie de générer à partir des données
        device_id = generate_device_id(data)
    
    device = MOCK_DEVICES.get(device_id)
    
    if not device:
        return jsonify({
            'device_id': device_id,
            'trusted': False,
            'compliance_score': 0,
            'trust_level': 'unknown',
            'message': 'Device not registered'
        })
    
    # Mettre à jour last_seen
    device['last_seen'] = datetime.utcnow().isoformat()
    
    response = jsonify({
        'device_id': device['device_id'],
        'trusted': device['trusted'],
        'compliance_score': device['compliance_score'],
        'trust_level': device['trust_level']
    })
    
    # Ajouter des headers pour le debugging
    response.headers['X-Device-Trusted'] = str(device['trusted']).lower()
    response.headers['X-Compliance-Score'] = str(device['compliance_score'])
    
    return response

@app.route('/api/devices', methods=['GET'])
def list_devices():
    """Liste tous les devices enregistrés"""
    return jsonify({
        'devices': list(MOCK_DEVICES.values()),
        'total': len(MOCK_DEVICES),
        'trusted_count': sum(1 for d in MOCK_DEVICES.values() if d['trusted'])
    })

@app.route('/api/devices/<device_id>', methods=['GET'])
def get_device(device_id):
    """Récupère les infos d'un device spécifique"""
    device = MOCK_DEVICES.get(device_id)
    if not device:
        return jsonify({'error': 'Device not found'}), 404
    return jsonify(device)

@app.route('/api/diagnostic', methods=['GET'])
def diagnostic():
    """Endpoint de diagnostic"""
    return jsonify({
        'service': 'device-posture',
        'status': 'healthy',
        'devices_count': len(MOCK_DEVICES),
        'opa_connected': check_opa_connection(),
        'timestamp': datetime.utcnow().isoformat()
    })

if __name__ == '__main__':
    logger.info("🚀 Device Posture Service Starting...")
    logger.info(f"📡 OPA URL: {OPA_URL}")
    app.run(host='0.0.0.0', port=8082, debug=True)